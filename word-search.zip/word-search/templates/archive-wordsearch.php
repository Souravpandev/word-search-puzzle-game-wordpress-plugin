<?php
/**
 * Template Name: Word Search Archive
 * Description: Displays all word search puzzles in a responsive grid layout.
 */

get_header(); ?>

<style>
    .wordsearch-archive {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }

    .wordsearch-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 25px;
        margin-top: 30px;
    }

    .wordsearch-item {
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .wordsearch-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
    }

    .wordsearch-thumbnail {
        height: 200px;
        background-color: #f5f5f5;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        overflow: hidden;
    }

    .wordsearch-thumbnail img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.3s ease;
    }

    .wordsearch-item:hover .wordsearch-thumbnail img {
        transform: scale(1.05);
    }

    .wordsearch-content {
        padding: 20px;
    }

    .wordsearch-title {
        margin: 0 0 10px;
        font-size: 1.25rem;
        line-height: 1.4;
    }

    .wordsearch-title a {
        color: #333;
        text-decoration: none;
        transition: color 0.2s ease;
    }

    .wordsearch-title a:hover {
        color: #0073aa;
    }

    .wordsearch-excerpt {
        color: #666;
        margin-bottom: 15px;
        font-size: 0.9rem;
        line-height: 1.6;
    }

    .wordsearch-meta {
        display: flex;
        justify-content: space-between;
        color: #888;
        font-size: 0.85rem;
    }

    .no-wordsearches {
        text-align: center;
        padding: 40px 20px;
        grid-column: 1 / -1;
    }

    @media (max-width: 768px) {
        .wordsearch-grid {
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        }
    }

    @media (max-width: 480px) {
        .wordsearch-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="wordsearch-archive">
    <h1><?php echo esc_html__('Word Search Puzzles', 'word-search'); ?></h1>
    
    <?php
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    $args = array(
        'post_type'      => 'wordsearch',
        'posts_per_page' => 12,
        'paged'          => $paged,
        'orderby'        => 'date',
        'order'          => 'DESC'
    );

    $word_searches = new WP_Query($args);

    if ($word_searches->have_posts()) : ?>
        <div class="wordsearch-grid">
            <?php while ($word_searches->have_posts()) : $word_searches->the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class('wordsearch-item'); ?>>
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="wordsearch-thumbnail">
                            <a href="<?php the_permalink(); ?>">
                                <?php the_post_thumbnail('large'); ?>
                            </a>
                        </div>
                    <?php else : ?>
                        <div class="wordsearch-thumbnail">
                            <a href="<?php the_permalink(); ?>">
                                <div style="display: flex; align-items: center; justify-content: center; height: 100%; background: #e9e9e9; color: #999; font-size: 1.2rem;">
                                    <?php echo esc_html__('Word Search', 'word-search'); ?>
                                </div>
                            </a>
                        </div>
                    <?php endif; ?>
                    
                    <div class="wordsearch-content">
                        <h2 class="wordsearch-title">
                            <a href="<?php the_permalink(); ?>">
                                <?php the_title(); ?>
                            </a>
                        </h2>
                        
                        <?php if (has_excerpt()) : ?>
                            <div class="wordsearch-excerpt">
                                <?php echo wp_trim_words(get_the_excerpt(), 20); ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="wordsearch-meta">
                            <span class="wordsearch-date"><?php echo get_the_date(); ?></span>
                            <span class="wordsearch-category">
                                <?php
                                $categories = get_the_terms(get_the_ID(), 'wordsearch-category');
                                if ($categories && !is_wp_error($categories)) {
                                    $category_names = array();
                                    foreach ($categories as $category) {
                                        $category_names[] = $category->name;
                                    }
                                    echo esc_html(implode(', ', $category_names));
                                }
                                ?>
                            </span>
                        </div>
                    </div>
                </article>
            <?php endwhile; ?>
        </div>

        <?php
        // Pagination
        $big = 999999999; // need an unlikely integer
        echo '<div class="wordsearch-pagination">';
        echo paginate_links(array(
            'base'      => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
            'format'    => '?paged=%#%',
            'current'   => max(1, $paged),
            'total'     => $word_searches->max_num_pages,
            'prev_text' => '&laquo; ' . esc_html__('Previous', 'word-search'),
            'next_text' => esc_html__('Next', 'word-search') . ' &raquo;',
        ));
        echo '</div>';
        ?>

        <?php wp_reset_postdata(); ?>

    <?php else : ?>
        <div class="no-wordsearches">
            <p><?php esc_html_e('No word search puzzles found.', 'word-search'); ?></p>
        </div>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
