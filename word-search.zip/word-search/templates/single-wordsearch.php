<?php
/**
 * The template for displaying single Word Search puzzles
 *
 * @package Word_Search
 */

get_header();
?>

<main id="primary" class="site-main word-search-single">
    <?php
    while (have_posts()) :
        the_post();
        
        // Get word list for SEO and display
        $words = get_post_meta(get_the_ID(), '_word_search_words', true);
        $words = is_array($words) ? $words : array();
        ?>
        
        <article id="post-<?php the_ID(); ?>" <?php post_class('word-search-article'); ?>>
            <?php if (function_exists('rank_math_the_breadcrumbs')) : ?>
                <div class="word-search-breadcrumbs">
                    <?php rank_math_the_breadcrumbs(); ?>
                </div>
            <?php endif; ?>
            
            <header class="entry-header">
                <?php the_title('<h1 class="entry-title">', '</h1>'); ?>
                
                <!-- Static Game Instructions -->
                <div class="word-search-instructions">
                    <h2><?php esc_html_e('How to Play', 'word-search'); ?></h2>
                    <p><?php esc_html_e('Find all the hidden words in the grid. Words can be horizontal, vertical, or diagonal, and may be forwards or backwards.', 'word-search'); ?></p>
                    
                    <?php if (!empty($words)) : ?>
                        <div class="word-search-seo-word-list" style="display:none;" aria-hidden="true">
                            <h3><?php esc_html_e('Word List', 'word-search'); ?>:</h3>
                            <p><?php echo esc_html(implode(', ', $words)); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </header>

            <div class="entry-content">
                <!-- Timer Controls -->
                <div class="word-search-timer-container">
                    <div class="timer-display">
                        <span id="timer-minutes">00</span>:<span id="timer-seconds">00</span>.<span id="timer-milliseconds">00</span>
                    </div>
                    <div class="timer-controls">
                        <button type="button" id="start-timer" class="timer-button"><?php esc_html_e('Start', 'word-search'); ?></button>
                        <button type="button" id="stop-timer" class="timer-button" disabled><?php esc_html_e('Pause', 'word-search'); ?></button>
                        <button type="button" id="reset-timer" class="timer-button"><?php esc_html_e('Reset', 'word-search'); ?></button>
                        <div class="timer-mode-selector">
                            <label>
                                <input type="radio" name="timer-mode" value="stopwatch" checked>
                                <?php esc_html_e('Stopwatch', 'word-search'); ?>
                            </label>
                            <label>
                                <input type="radio" name="timer-mode" value="countdown">
                                <?php esc_html_e('Countdown', 'word-search'); ?>
                            </label>
                            <div id="countdown-settings" style="display: none;">
                                <input type="number" id="countdown-minutes" min="1" max="60" value="5" style="width: 50px;">
                                <span><?php esc_html_e('minutes', 'word-search'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php
                // Display the word search puzzle
                echo do_shortcode('[wordsearch id="' . get_the_ID() . '"]');
                
                // Display the content if any
                the_content();
                
                // Display word list
                if (!empty($words)) : ?>
                   
                <?php endif; ?>
                
                <!-- Social Sharing -->
                <div class="word-search-social-share">
                    <h3 class="share-title"><?php esc_html_e('Share This Puzzle', 'word-search'); ?></h3>
                    <div class="share-buttons">
                        <!-- Facebook -->
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" 
                           class="share-button share-facebook" 
                           target="_blank" 
                           rel="noopener noreferrer"
                           aria-label="<?php esc_attr_e('Share on Facebook', 'word-search'); ?>">
                            <span class="screen-reader-text"><?php esc_html_e('Share on Facebook', 'word-search'); ?></span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#1877F2">
                                <path d="M22.675 0H1.325C.593 0 0 .593 0 1.325v21.351C0 23.407.593 24 1.325 24H12.82v-9.294H9.692v-3.622h3.128V8.413c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12V24h6.116c.73 0 1.323-.593 1.323-1.325V1.325C24 .593 23.407 0 22.675 0z"/>
                            </svg>
                        </a>
                        
                        <!-- Twitter -->
                        <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode(get_permalink()); ?>&text=<?php echo urlencode(get_the_title()); ?>" 
                           class="share-button share-twitter" 
                           target="_blank" 
                           rel="noopener noreferrer"
                           aria-label="<?php esc_attr_e('Share on Twitter', 'word-search'); ?>">
                            <span class="screen-reader-text"><?php esc_html_e('Share on Twitter', 'word-search'); ?></span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#1DA1F2">
                                <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                            </svg>
                        </a>
                        
                        <!-- LinkedIn -->
                        <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode(get_permalink()); ?>&title=<?php echo urlencode(get_the_title()); ?>" 
                           class="share-button share-linkedin" 
                           target="_blank" 
                           rel="noopener noreferrer"
                           aria-label="<?php esc_attr_e('Share on LinkedIn', 'word-search'); ?>">
                            <span class="screen-reader-text"><?php esc_html_e('Share on LinkedIn', 'word-search'); ?></span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#0A66C2">
                                <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                            </svg>
                        </a>
                        
                        <!-- WhatsApp -->
                        <a href="https://wa.me/?text=<?php echo urlencode(get_the_title() . ' - ' . get_permalink()); ?>" 
                           class="share-button share-whatsapp" 
                           target="_blank" 
                           rel="noopener noreferrer"
                           aria-label="<?php esc_attr_e('Share on WhatsApp', 'word-search'); ?>">
                            <span class="screen-reader-text"><?php esc_html_e('Share on WhatsApp', 'word-search'); ?></span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#25D366">
                                <path d="M17.498 14.382a.96.96 0 01-.7.3c-.193 0-.53-.099-.772-.274-.36-.245-.86-.6-1.658-.6-.76 0-1.16.433-1.44.81-.2.27-.6.9-.6 1.73 0 .83.43 1.142.73 1.382.24.19.47.2.67.2.19 0 .36-.28.7-1.08.1-.25.23-.43.4-.56.24-.2.52-.25.69-.25s.31.04.45.09c.14.04.31.2.44.37.13.17.18.19.3.19.1 0 .27-.05.55-.5.24-.4.49-1.02.54-1.37.03-.18-.06-.28-.13-.35-.1-.1-.22-.14-.35-.22l-.01-.01c-.16-.08-.4-.2-.57-.31-.18-.12-.3-.2-.36-.33-.08-.13 0-.24.06-.32.07-.09.16-.23.25-.36.08-.13.11-.22.16-.36.04-.13.02-.24-.02-.35-.04-.11-.35-.85-.48-1.16-.13-.31-.26-.27-.35-.28-.09 0-.19-.01-.28-.01-.1 0-.26.04-.4.19-.14.15-.52.52-.52 1.26 0 .74.54 1.46.62 1.56.08.1 1.1 1.67 2.67 2.35.37.16.66.26.89.34.37.12.7.1.96.06.29-.04.7-.29.8-.57.1-.28.1-.52.07-.57-.03-.09-.12-.14-.22-.22l-.01-.01z"/>
                                <path d="M12 2a10 10 0 00-8.5 15.31l-1.34 4.04 4.2-1.31A9.94 9.94 0 0012 22a10 10 0 000-20zm0 18.5a8.5 8.5 0 01-4.33-1.18l-.3-.18-3.12.98.98-3.1-.24-.37A8.5 8.5 0 1112 20.5z"/>
                            </svg>
                        </a>
                        
                        <!-- Email -->
                        <a href="mailto:?subject=<?php echo rawurlencode(sprintf(__('Check out this word search: %s', 'word-search'), get_the_title())); ?>&body=<?php echo rawurlencode(sprintf(__('I found this interesting word search: %s - %s', 'word-search'), get_the_title(), get_permalink())); ?>" 
                           class="share-button share-email" 
                           aria-label="<?php esc_attr_e('Share via Email', 'word-search'); ?>">
                            <span class="screen-reader-text"><?php esc_html_e('Share via Email', 'word-search'); ?></span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#EA4335">
                                <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                            </svg>
                        </a>
                    </div>
                </div>
                
                <!-- Related Games -->
                <?php
                $related_args = array(
                    'post_type'      => 'wordsearch',
                    'posts_per_page' => 3,
                    'post__not_in'   => array(get_the_ID()),
                    'orderby'        => 'rand',
                    'tax_query'      => array(
                        array(
                            'taxonomy' => 'wordsearch_category',
                            'field'    => 'term_id',
                            'terms'    => wp_get_post_terms(get_the_ID(), 'wordsearch_category', array('fields' => 'ids')),
                            'operator' => 'IN'
                        )
                    )
                );
                
                $related_games = new WP_Query($related_args);
                
                if ($related_games->have_posts()) : ?>
                    <div class="word-search-related-games">
                        <h2><?php esc_html_e('More Word Search Puzzles', 'word-search'); ?></h2>
                        <ul class="related-games-list">
                            <?php while ($related_games->have_posts()) : $related_games->the_post(); ?>
                                <li>
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_title(); ?>
                                    </a>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    </div>
                    <?php wp_reset_postdata(); ?>
                <?php endif; ?>
            </div>

            <footer class="entry-footer">
                <?php
                // Display post meta information
                echo '<div class="word-search-meta">';
                echo '<span class="posted-on">' . sprintf(
                    /* translators: %s: post date. */
                    esc_html_x('Created on %s', 'post date', 'word-search'),
                    '<span>' . esc_html(get_the_date()) . '</span>'
                ) . '</span>';
                echo '</div>';
                ?>
            </footer>
        </article>

        <?php
        // If comments are open or we have at least one comment, load up the comment template.
        if (comments_open() || get_comments_number()) :
            comments_template();
        endif;
        ?>

    <?php endwhile; // End of the loop. ?>
</main><!-- #main -->

<?php
get_sidebar();
get_footer();
