<?php
/**
 * Template Name: Word Search Category
 * Template for displaying word search puzzles by category
 */

get_header();
?>

<style>
    .wordsearch-category-archive {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    }

    .wordsearch-category-header {
        text-align: center;
        margin-bottom: 40px;
        padding: 20px;
        background: #f8f9fa;
        border-radius: 8px;
    }

    .wordsearch-category-title {
        font-size: 2.5em;
        color: #2c3e50;
        margin-bottom: 15px;
    }

    .wordsearch-category-description {
        font-size: 1.1em;
        color: #555;
        line-height: 1.6;
        max-width: 800px;
        margin: 0 auto;
    }

    .wordsearch-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 25px;
        padding: 20px 0;
    }

    .wordsearch-item {
        background: #fff;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .wordsearch-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 6px 12px rgba(0,0,0,0.15);
    }

    .wordsearch-thumbnail {
        width: 100%;
        height: 180px;
        object-fit: cover;
    }

    .wordsearch-content {
        padding: 20px;
    }

    .wordsearch-title {
        font-size: 1.2em;
        margin: 0 0 10px 0;
    }

    .wordsearch-title a {
        color: #2c3e50;
        text-decoration: none;
        transition: color 0.2s ease;
    }

    .wordsearch-title a:hover {
        color: #3498db;
    }

    .wordsearch-excerpt {
        color: #666;
        font-size: 0.95em;
        line-height: 1.5;
        margin-bottom: 15px;
    }

    .wordsearch-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 0.85em;
        color: #7f8c8d;
    }

    .wordsearch-difficulty {
        display: inline-block;
        padding: 3px 10px;
        border-radius: 12px;
        font-size: 0.8em;
        font-weight: 500;
    }

    .difficulty-easy { background: #e8f5e9; color: #2e7d32; }
    .difficulty-medium { background: #e3f2fd; color: #1565c0; }
    .difficulty-hard { background: #ffebee; color: #c62828; }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .wordsearch-grid {
            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
            gap: 20px;
        }
        
        .wordsearch-item {
            margin-bottom: 20px;
        }
    }

    @media (max-width: 480px) {
        .wordsearch-category-title {
            font-size: 2em;
        }
        
        .wordsearch-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="wordsearch-category-archive">
    <header class="wordsearch-category-header">
        <h1 class="wordsearch-category-title"><?php single_term_title('Category: '); ?></h1>
        <?php if (term_description()) : ?>
            <div class="wordsearch-category-description">
                <?php echo term_description(); ?>
            </div>
        <?php endif; ?>
    </header>

    <div class="wordsearch-grid">
        <?php if (have_posts()) : 
            while (have_posts()) : the_post(); 
                // Get the difficulty level
                $difficulty = get_post_meta(get_the_ID(), '_wordsearch_difficulty', true);
                $difficulty_class = !empty($difficulty) ? 'difficulty-' . strtolower($difficulty) : '';
                $difficulty_display = !empty($difficulty) ? $difficulty : 'Easy'; // Default to Easy if not set
                ?>
                
                <article class="wordsearch-item">
                    <?php if (has_post_thumbnail()) : ?>
                        <a href="<?php the_permalink(); ?>" class="wordsearch-thumbnail-link">
                            <?php the_post_thumbnail('medium_large', array('class' => 'wordsearch-thumbnail')); ?>
                        </a>
                    <?php endif; ?>
                    
                    <div class="wordsearch-content">
                        <h2 class="wordsearch-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h2>
                        
                        <?php if (has_excerpt()) : ?>
                            <div class="wordsearch-excerpt">
                                <?php echo get_the_excerpt(); ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="wordsearch-meta">
                            <span class="wordsearch-difficulty <?php echo esc_attr($difficulty_class); ?>">
                                <?php echo esc_html($difficulty_display); ?>
                            </span>
                            <a href="<?php the_permalink(); ?>" class="button">
                                <?php esc_html_e('Play Now', 'word-search'); ?>
                            </a>
                        </div>
                    </div>
                </article>
                
            <?php endwhile; 
            
            // Pagination
            the_posts_pagination(array(
                'mid_size'  => 2,
                'prev_text' => __('&larr; Previous', 'word-search'),
                'next_text' => __('Next &rarr;', 'word-search'),
            ));
            
        else : ?>
            <p class="no-wordsearches">
                <?php esc_html_e('No word search puzzles found in this category.', 'word-search'); ?>
            </p>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>
