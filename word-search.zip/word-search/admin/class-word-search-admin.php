<?php
class Word_Search_Admin {
    public function enqueue_styles() {
        wp_enqueue_style('word-search-admin', plugin_dir_url(dirname(__FILE__)) . 'admin/css/word-search-admin.css', array(), WORD_SEARCH_VERSION, 'all');
    }

    public function enqueue_scripts() {
        wp_enqueue_script('wordfind', plugin_dir_url(dirname(__FILE__)) . 'public/js/wordfind.js', array('jquery'), '1.0', true);
        wp_enqueue_script('wordfind-js', plugin_dir_url(dirname(__FILE__)) . 'public/js/wordfind-js.js', array('jquery', 'wordfind'), '1.0', true);
        wp_enqueue_script('word-search-admin', plugin_dir_url(dirname(__FILE__)) . 'admin/js/word-search-admin.js', array('jquery', 'wordfind', 'wordfind-js'), WORD_SEARCH_VERSION, true);
    }
}