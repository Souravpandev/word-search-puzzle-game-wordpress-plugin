jQuery(document).ready(function($) {
    // Check if we're on the word search edit screen
    if ($('#word_search_words').length) {
        // Initialize word search preview
        var wordsTextarea = $('#word_search_words');
        var previewContainer = $('<div id="word-search-preview" style="margin-top: 20px;"></div>');
        var puzzleContainer = $('<div id="puzzle-preview" style="margin: 20px 0;"></div>');
        var wordsContainer = $('<div id="words-preview"></div>');
        
        previewContainer.append(puzzleContainer);
        previewContainer.append(wordsContainer);
        wordsTextarea.after(previewContainer);
        
        // Generate preview when textarea changes
        wordsTextarea.on('input', function() {
            updateWordSearchPreview();
        });
        
        function updateWordSearchPreview() {
            var wordsText = wordsTextarea.val();
            var words = wordsText.split('\n').filter(function(word) {
                return word.trim() !== '';
            });
            
            if (words.length === 0) {
                puzzleContainer.html('<p>No words to display. Add words above to see a preview.</p>');
                wordsContainer.empty();
                return;
            }
            
            try {
                // Generate the puzzle
                var puzzle = wordfindgame.create(words, {
                    // Puzzle settings
                    width: 12,
                    height: 12,
                    fillBlanks: true,
                    maxAttempts: 20,
                    maxGridGrowth: 10
                });
                
                // Display the puzzle
                var puzzleHtml = wordfindgame.print(puzzle);
                puzzleContainer.html(puzzleHtml);
                
                // Display the word list
                var wordsHtml = '<h4>Words to find:</h4><ul class="word-list">';
                words.forEach(function(word) {
                    wordsHtml += '<li>' + word + '</li>';
                });
                wordsHtml += '</ul>';
                wordsContainer.html(wordsHtml);
                
            } catch (e) {
                puzzleContainer.html('<p>Error generating preview: ' + e.message + '</p>');
                console.error(e);
            }
        }
        
        // Initial preview update
        updateWordSearchPreview();
    }
});
