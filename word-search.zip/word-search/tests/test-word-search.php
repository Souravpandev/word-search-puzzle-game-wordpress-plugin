<?php
/**
 * Test file for Word Search Plugin
 * 
 * This file contains test cases to verify the functionality of the Word Search plugin.
 * It tests the WordFind and WordFindGrid classes, as well as the plugin's integration with WordPress.
 */

define('WP_USE_THEMES', false);
require_once('wp-load.php');

class WordSearchPluginTest extends WP_UnitTestCase {
    
    /**
     * Test the WordFindGrid class
     */
    public function testWordFindGrid() {
        require_once(plugin_dir_path(dirname(__FILE__)) . 'includes/wordfind/WordFindGrid.php');
        
        $grid = new WordFind\WordFindGrid(10, 10);
        
        // Test placing a word horizontally
        $this->assertTrue($grid->placeWord('TEST', [1, 0], 0, 0));
        
        // Test placing a word vertically
        $this->assertTrue($grid->placeWord('TEST', [0, 1], 0, 0));
        
        // Test placing a word diagonally
        $this->assertTrue($grid->placeWord('TEST', [1, 1], 0, 0));
        
        // Test invalid placement (out of bounds)
        $this->assertFalse($grid->placeWord('TEST', [1, 0], 8, 0));
        
        // Test conflicting placement
        $grid = new WordFind\WordFindGrid(10, 10);
        $this->assertTrue($grid->placeWord('TEST', [1, 0], 0, 0));
        $this->assertFalse($grid->placeWord('WORD', [1, 0], 2, 0));
    }
    
    /**
     * Test the WordFind class
     */
    public function testWordFind() {
        require_once(plugin_dir_path(dirname(__FILE__)) . 'includes/wordfind/WordFind.php');
        require_once(plugin_dir_path(dirname(__FILE__)) . 'includes/wordfind/WordFindGrid.php');
        
        $words = ['TEST', 'WORD', 'SEARCH', 'PUZZLE'];
        $wordFind = new WordFind\WordFind($words);
        
        // Test puzzle generation
        $grid = $wordFind->generate();
        $this->assertIsArray($grid);
        $this->assertNotEmpty($grid);
        
        // Test placed words
        $placedWords = $wordFind->getPlacedWords();
        $this->assertGreaterThanOrEqual(1, count($placedWords));
        
        // Verify all placed words were in the original list
        foreach ($placedWords as $word) {
            $this->assertContains($word, $words);
        }
    }
    
    /**
     * Test the plugin's main class
     */
    public function testWordSearchPlugin() {
        // Test custom post type registration
        $post_types = get_post_types();
        $this->assertArrayHasKey('wordsearch', $post_types);
        
        // Test shortcode registration
        global $shortcode_tags;
        $this->assertArrayHasKey('wordsearch', $shortcode_tags);
    }
    
    /**
     * Test word search creation and retrieval
     */
    public function testWordSearchCreation() {
        // Create a test word search
        $post_id = $this->factory->post->create([
            'post_type' => 'wordsearch',
            'post_title' => 'Test Word Search',
            'post_status' => 'publish'
        ]);
        
        // Set test words
        $test_words = ['TEST', 'WORD', 'SEARCH'];
        update_post_meta($post_id, '_word_search_words', $test_words);
        
        // Test word retrieval
        $words = get_post_meta($post_id, '_word_search_words', true);
        $this->assertEquals($test_words, $words);
        
        // Test shortcode output
        $shortcode_output = do_shortcode('[wordsearch id="' . $post_id . '"]');
        $this->assertStringContainsString('word-search-container', $shortcode_output);
        
        // Clean up
        wp_delete_post($post_id, true);
    }
    
    /**
     * Test the plugin's database table
     */
    public function testDatabaseTable() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wordsearch';
        
        // Check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'");
        $this->assertEquals($table_name, $table_exists);
        
        // Check table structure
        $columns = $wpdb->get_results("DESCRIBE $table_name");
        $column_names = wp_list_pluck($columns, 'Field');
        
        $expected_columns = ['id', 'title', 'words', 'grid', 'settings', 'created_at', 'updated_at'];
        foreach ($expected_columns as $column) {
            $this->assertContains($column, $column_names);
        }
    }
}

// Run the tests
$test = new WordSearchPluginTest();
$test->setUp();
$test->testWordFindGrid();
$test->testWordFind();
$test->testWordSearchPlugin();
$test->testWordSearchCreation();
$test->testDatabaseTable();
$test->tearDown();

echo "All tests passed successfully!\n";
