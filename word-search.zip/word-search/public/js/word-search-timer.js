jQuery(document).ready(function($) {
    'use strict';

    // DOM Elements
    const $timerDisplay = $('.timer-display');
    const $minutes = $('#timer-minutes');
    const $seconds = $('#timer-seconds');
    const $milliseconds = $('#timer-milliseconds');
    const $startBtn = $('#start-timer');
    const $stopBtn = $('#stop-timer');
    const $resetBtn = $('#reset-timer');
    const $modeRadios = $('input[name="timer-mode"]');
    const $countdownSettings = $('#countdown-settings');
    const $countdownMinutes = $('#countdown-minutes');

    // Timer variables
    let timer = null;
    let isRunning = false;
    let startTime = 0;
    let elapsedTime = 0;
    let countdownTime = 0;
    let isCountdown = false;

    // Initialize timer display
    function updateDisplay(timeInMs) {
        let remaining = timeInMs;
        
        // Calculate time components
        const minutes = Math.floor(remaining / 60000);
        remaining %= 60000;
        const seconds = Math.floor(remaining / 1000);
        remaining %= 1000;
        const milliseconds = Math.floor(remaining / 10);

        // Update display
        $minutes.text(String(minutes).padStart(2, '0'));
        $seconds.text(String(seconds).padStart(2, '0'));
        $milliseconds.text(String(milliseconds).padStart(2, '0'));

        // Update visual feedback
        if (isCountdown) {
            const totalSeconds = (countdownTime / 1000);
            const remainingSeconds = (timeInMs / 1000);
            
            // Remove all timer state classes first
            $timerDisplay.removeClass('timer-warning timer-danger');
            
            // Add appropriate warning classes based on remaining time
            if (remainingSeconds <= totalSeconds * 0.2) {
                $timerDisplay.addClass('timer-danger');
            } else if (remainingSeconds <= totalSeconds * 0.5) {
                $timerDisplay.addClass('timer-warning');
            }
        } else {
            $timerDisplay.toggleClass('timer-running', isRunning);
        }
    }

    // Format time for display
    function formatTime(ms) {
        const date = new Date(ms);
        return date.toISOString().substr(11, 8) + '.' + 
               String(date.getMilliseconds()).padStart(3, '0').substr(0, 2);
    }

    // Start the timer
    function startTimer() {
        if (!isRunning) {
            if (isCountdown && elapsedTime <= 0) {
                // Don't start if countdown is already at 0
                return;
            }
            
            isRunning = true;
            startTime = Date.now() - (isCountdown ? (countdownTime - elapsedTime) : elapsedTime);
            
            $startBtn.prop('disabled', true);
            $stopBtn.prop('disabled', false);
            
            timer = setInterval(updateTimer, 10);
        }
    }

    // Stop the timer
    function stopTimer() {
        if (isRunning) {
            isRunning = false;
            clearInterval(timer);
            
            $startBtn.prop('disabled', false);
            $stopBtn.prop('disabled', true);
            
            // If countdown reached zero, show completion message
            if (isCountdown && elapsedTime <= 0) {
                alert('Time\'s up!');
                resetTimer();
            }
        }
    }

    // Reset the timer
    function resetTimer() {
        stopTimer();
        
        if (isCountdown) {
            countdownTime = parseInt($countdownMinutes.val()) * 60 * 1000;
            elapsedTime = countdownTime;
        } else {
            elapsedTime = 0;
        }
        
        updateDisplay(elapsedTime);
        $timerDisplay.removeClass('timer-running timer-warning timer-danger');
    }

    // Update timer display
    function updateTimer() {
        const currentTime = Date.now();
        
        if (isCountdown) {
            elapsedTime = Math.max(0, countdownTime - (currentTime - startTime));
            updateDisplay(elapsedTime);
            
            if (elapsedTime <= 0) {
                stopTimer();
            }
        } else {
            elapsedTime = currentTime - startTime;
            updateDisplay(elapsedTime);
        }
    }

    // Toggle countdown settings visibility
    function toggleCountdownSettings() {
        isCountdown = ($('input[name="timer-mode"]:checked').val() === 'countdown');
        $countdownSettings.toggle(isCountdown);
        resetTimer();
    }

    // Event Listeners
    $startBtn.on('click', startTimer);
    $stopBtn.on('click', stopTimer);
    $resetBtn.on('click', resetTimer);
    $modeRadios.on('change', toggleCountdownSettings);
    $countdownMinutes.on('change', resetTimer);

    // Initialize
    toggleCountdownSettings();
    resetTimer();
});
