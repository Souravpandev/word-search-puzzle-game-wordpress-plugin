jQuery(document).ready(function($) {
    'use strict';

    // Remove any existing print buttons to prevent duplicates
    $('#print-puzzle').remove();
    
    // Add a single print button after the last button in the controls
    $('.word-search-controls').append(
        '<button type="button" id="print-puzzle" class="button button-secondary" style="margin-left: 10px;">' +
        '<span class="dashicons dashicons-pdf" style="vertical-align: middle; margin-right: 4px;"></span>' +
        'Print/Download PDF' +
        '</button>'
    );

    // Function to split array into chunks
    function chunkArray(array, size) {
        const chunks = [];
        for (let i = 0; i < array.length; i += size) {
            chunks.push(array.slice(i, i + size));
        }
        return chunks;
    }

    // Handle print button click
    $(document).on('click', '#print-puzzle', async function(e) {
        e.preventDefault();
        
        // Show loading state
        const $button = $(this);
        const originalText = $button.html();
        $button.html('<span class="spinner" style="visibility: visible; margin-left: 0; float: none;"></span> Generating PDF...');
        $button.prop('disabled', true);
        
        try {
            // Get puzzle elements and metadata
            const websiteName = 'Biologynotesonline.com';
            const title = $('.entry-title').text().trim();
            const sanitizedTitle = title.replace(/[^a-z0-9\s-]/gi, '').replace(/\s+/g, '-').toLowerCase();
            const filename = `${sanitizedTitle}-${websiteName}.pdf`;
            
            const $puzzleGrid = $('.word-search-grid').first().clone();
            const words = [];
            
            // Extract words from the word list
            $('.word-search-word-list li').each(function() {
                words.push($(this).text().trim());
            });
            
            // Create a temporary container for the PDF content
            const $tempContainer = $('<div>').css({
                position: 'absolute',
                left: '-9999px',
                width: '210mm',
                padding: '20mm',
                boxSizing: 'border-box',
                fontFamily: 'Arial, sans-serif',
                backgroundColor: 'white'
            }).appendTo('body');
            
            // Add title
            $tempContainer.append(`
                <div style="text-align: center; margin-bottom: 20px;">
                    <h1 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">${title}</h1>
                    <div style="height: 2px; background: #ddd; margin: 10px 0 20px 0;"></div>
                </div>
            `);
            
            // Add puzzle grid
            $tempContainer.append('<div id="puzzle-container" style="margin: 0 auto; max-width: 100%;">');
            $('#puzzle-container', $tempContainer).append($puzzleGrid);
            
            // Style the grid for printing
            $('table', $tempContainer).css({
                borderCollapse: 'collapse',
                margin: '0 auto',
                border: '2px solid #000'
            });
            
            $('td', $tempContainer).css({
                width: '30px',
                height: '30px',
                border: '1px solid #000',
                textAlign: 'center',
                verticalAlign: 'middle',
                fontSize: '16px',
                fontWeight: 'bold',
                padding: 0
            });
            
            // Add word list in columns
            const columns = 3;
            const wordsPerColumn = Math.ceil(words.length / columns);
            const wordChunks = chunkArray(words, wordsPerColumn);
            
            let wordListHtml = `
                <div style="margin-top: 30px;">
                    <h3 style="text-align: center; margin: 0 0 15px 0; font-size: 18px; color: #333;">
                        Word List
                    </h3>
                    <div style="display: flex; justify-content: center;">
            `;
            
            wordChunks.forEach(chunk => {
                wordListHtml += `
                    <div style="flex: 1; padding: 0 15px;">
                        <ul style="list-style: none; padding: 0; margin: 0; text-align: center;">
                `;
                
                chunk.forEach(word => {
                    wordListHtml += `<li style="margin: 5px 0; font-size: 14px;">${word}</li>`;
                });
                
                wordListHtml += `
                        </ul>
                    </div>
                `;
            });
            
            wordListHtml += `
                    </div>
                </div>
            `;
            
            $tempContainer.append(wordListHtml);
            
            // Add footer with website name
            $tempContainer.append(`
                <div style="margin-top: 30px; padding-top: 15px; border-top: 1px solid #eee; text-align: center; font-size: 12px; color: #666;">
                    ${websiteName}
                </div>
            `);
            
            // Generate PDF
            const canvas = await html2canvas($tempContainer[0], {
                scale: 2,
                useCORS: true,
                allowTaint: true,
                logging: false,
                backgroundColor: '#fff'
            });
            
            const { jsPDF } = window.jspdf;
            const pdf = new jsPDF('p', 'mm', 'a4');
            const imgData = canvas.toDataURL('image/png');
            
            // Calculate dimensions to fit the page while maintaining aspect ratio
            const pageWidth = pdf.internal.pageSize.getWidth();
            const pageHeight = pdf.internal.pageSize.getHeight();
            const imgWidth = pageWidth;
            const imgHeight = (canvas.height * imgWidth) / canvas.width;
            
            // Add image to PDF
            pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
            
            // Add page numbers to each page
            const pageCount = pdf.getNumberOfPages();
            for (let i = 1; i <= pageCount; i++) {
                pdf.setPage(i);
                // Add page number at the bottom
                pdf.setFontSize(10);
                pdf.setTextColor(100);
                const pageWidth = pdf.internal.pageSize.getWidth();
                const pageHeight = pdf.internal.pageSize.getHeight();
                pdf.text(
                    `Page ${i} of ${pageCount}`,
                    pageWidth - 20,
                    pageHeight - 10
                );
            }
            
            // Save the PDF
            pdf.save(filename);
            
        } catch (error) {
            console.error('Error generating PDF:', error);
            alert('Error generating PDF. Please try again.');
        } finally {
            // Clean up
            $('.pdf-temp-container').remove();
            $button.html(originalText).prop('disabled', false);
        }
    });
});
