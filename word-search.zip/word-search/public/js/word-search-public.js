jQuery(document).ready(function($) {
    $('.word-search-container').each(function() {
        var container = $(this);
        var words = [];
        
        try {
            words = JSON.parse(container.attr('data-words') || '[]');
        } catch (e) {
            console.error('Error parsing word list:', e);
            container.html('<p>Error loading word search. Please try again.</p>');
            return;
        }
        
        if (!words || !words.length) {
            container.html('<p>No words found for this word search.</p>');
            return;
        }
        
        // Create puzzle container
        var puzzleContainer = $('<div class="word-search-puzzle"></div>');
        var wordsContainer = $('<div class="word-search-words"></div>');
        var controlsContainer = $('<div class="word-search-controls"></div>');
        
        // Clear existing content
        container.empty();
        container.append(puzzleContainer);
        container.append(wordsContainer);
        container.append(controlsContainer);
        
        // Add solve button
        var solveButton = $('<button class="button">Solve</button>');
        var newGameButton = $('<button class="button" style="margin-left: 10px;">New Game</button>');
        controlsContainer.append(solveButton);
        controlsContainer.append(newGameButton);
        
        // Initialize the game
        var game = {
            puzzle: null,
            words: words,
            settings: {
                width: 12,
                height: 12,
                fillBlanks: true,
                maxAttempts: 20,
                maxGridGrowth: 10,
                orientations: ['horizontal', 'vertical', 'diagonal', 'diagonalUp']
            },
            init: function() {
                this.generatePuzzle();
                this.renderWords();
            },
            generatePuzzle: function() {
                try {
                    // Create a copy of words to avoid modifying the original
                    var wordsToPlace = this.words.slice();
                    
                    // Generate the puzzle using wordfind.js
                    var puzzle = wordfind.newPuzzle(wordsToPlace, this.settings);
                    
                    // Store puzzle data
                    this.puzzle = {
                        grid: puzzle,
                        words: wordsToPlace
                    };
                    
                    // Render the puzzle
                    this.renderPuzzle();
                    this.setupPuzzleEvents();
                    
                    // Debug output
                    console.log('Puzzle generated with words:', wordsToPlace);
                    
                } catch (e) {
                    console.error('Error generating puzzle:', e);
                    puzzleContainer.html('<p>Error generating puzzle. Please try again with different words or settings.</p>');
                }
            },
            renderPuzzle: function() {
                var self = this;
                var html = '<table class="word-search-grid">';
                
                // Generate the grid HTML
                for (var i = 0; i < self.puzzle.grid.length; i++) {
                    html += '<tr>';
                    for (var j = 0; j < self.puzzle.grid[i].length; j++) {
                        var letter = self.puzzle.grid[i][j] || '';
                        html += '<td data-row="' + i + '" data-col="' + j + '">' + 
                               letter.toUpperCase() + '</td>';
                    }
                    html += '</tr>';
                }
                html += '</table>';
                
                // Update the puzzle container
                puzzleContainer.html(html);
                
                // Add styling for better visibility
                $('.word-search-grid').css({
                    'border-collapse': 'collapse',
                    'margin': '20px 0'
                });
                
                $('.word-search-grid td').css({
                    'width': '30px',
                    'height': '30px',
                    'border': '1px solid #ccc',
                    'text-align': 'center',
                    'vertical-align': 'middle',
                    'font-size': '18px',
                    'cursor': 'pointer',
                    'user-select': 'none'
                });
                
                return html;
            },
            
            renderWords: function() {
                wordsContainer.empty();
                var wordsList = $('<ul class="word-search-word-list"></ul>');
                
                // Add each word to the list
                this.words.forEach(function(word) {
                    wordsList.append($('<li>').text(word.toUpperCase()));
                });
                
                wordsContainer.append($('<h3>').text('Find these words:'));
                wordsContainer.append(wordsList);
                
                // Style the word list
                $('.word-search-word-list').css({
                    'list-style': 'none',
                    'padding': '0',
                    'display': 'flex',
                    'flex-wrap': 'wrap',
                    'gap': '10px',
                    'margin': '10px 0'
                });
                
                $('.word-search-word-list li').css({
                    'padding': '5px 10px',
                    'background': '#f0f0f0',
                    'border-radius': '3px',
                    'font-size': '16px'
                });
                
                $('.word-search-word-list li.found').css({
                    'text-decoration': 'line-through',
                    'color': '#888'
                });
            },
            setupPuzzleEvents: function() {
                var self = this;
                var isMouseDown = false;
                var startCell = null;
                var selectedCells = [];
                
                // Clear any existing event handlers
                $('.word-search-grid').off('mousedown touchstart')
                                   .off('mousemove touchmouse')
                                   .off('mouseup touchend');
                
                // Mouse/Touch down
                var onPointerDown = function(e) {
                    var cell = $(e.target).closest('td');
                    if (!cell.length || cell.hasClass('found')) return;
                    
                    e.preventDefault();
                    e.stopPropagation();
                    
                    isMouseDown = true;
                    startCell = cell;
                    selectedCells = [cell];
                    
                    // Clear any previous selection
                    $('.word-search-grid td').removeClass('selected invalid');
                    cell.addClass('selected');
                    
                    // Prevent text selection during drag
                    return false;
                };
                
                // Mouse/Touch move
                var onPointerMove = function(e) {
                    if (!isMouseDown || !startCell) return;
                    
                    e.preventDefault();
                    e.stopPropagation();
                    
                    var cell = $(e.target).closest('td');
                    if (!cell.length) return;
                    
                    // Don't process if we're still on the same cell
                    if (selectedCells.length === 1 && cell[0] === startCell[0]) return;
                    
                    // Clear previous selection
                    $('.word-search-grid td').removeClass('selected invalid');
                    
                    // Get coordinates
                    var startRow = parseInt(startCell.data('row'), 10);
                    var startCol = parseInt(startCell.data('col'), 10);
                    var endRow = parseInt(cell.data('row'), 10);
                    var endCol = parseInt(cell.data('col'), 10);
                    
                    // Calculate direction
                    var rowDiff = endRow - startRow;
                    var colDiff = endCol - startCol;
                    var rowStep = rowDiff === 0 ? 0 : (rowDiff > 0 ? 1 : -1);
                    var colStep = colDiff === 0 ? 0 : (colDiff > 0 ? 1 : -1);
                    
                    // Only allow straight lines and diagonals (no L-shapes)
                    if (rowStep !== 0 && colStep !== 0 && 
                        Math.abs(rowDiff) !== Math.abs(colDiff)) {
                        return;
                    }
                    
                    // Select cells in the line
                    selectedCells = [];
                    var currentRow = startRow;
                    var currentCol = startCol;
                    
                    while (true) {
                        var currentCell = $('.word-search-grid td[data-row="' + currentRow + '"][data-col="' + currentCol + '"]');
                        if (currentCell.length === 0) break;
                        
                        currentCell.addClass('selected');
                        selectedCells.push(currentCell);
                        
                        if (currentRow === endRow && currentCol === endCol) break;
                        
                        currentRow += rowStep;
                        currentCol += colStep;
                        
                        // Ensure we don't go out of bounds
                        if (currentRow < 0 || currentRow >= self.puzzle.grid.length || 
                            currentCol < 0 || currentCol >= self.puzzle.grid[0].length) {
                            break;
                        }
                    }
                };
                
                // Mouse/Touch up
                var onPointerUp = function(e) {
                    if (!isMouseDown) return;
                    e.preventDefault();
                    isMouseDown = false;
                    
                    if (selectedCells.length < 2) {
                        $('.word-search-grid td').removeClass('selected');
                        selectedCells = [];
                        return;
                    }
                    
                    // Get the selected word in both directions
                    var selectedWord = '';
                    
                    selectedCells.forEach(function(cell) {
                        selectedWord += cell.text().toLowerCase();
                    });
                    
                    // Check for words in both directions
                    var foundWord = null;
                    var foundIndex = -1;
                    
                    self.words.forEach(function(word, index) {
                        var lowerWord = word.toLowerCase();
                        if (lowerWord === selectedWord || 
                            lowerWord === selectedWord.split('').reverse().join('')) {
                            foundWord = word;
                            foundIndex = index;
                        }
                    });
                    
                    if (foundWord !== null) {
                        // Mark cells as found
                        selectedCells.forEach(function(cell) {
                            cell.addClass('found');
                        });
                        
                        // Mark word as found in the list
                        $('.word-search-word-list li').each(function(index) {
                            if ($(this).text().toLowerCase() === foundWord.toLowerCase()) {
                                $(this).addClass('found');
                            }
                        });
                        
                        // Check if all words are found
                        self.checkWin();
                    } else {
                        // Visual feedback for invalid selection
                        var tempSelected = selectedCells.slice();
                        tempSelected.forEach(function(cell) {
                            cell.addClass('invalid');
                            setTimeout(function() {
                                cell.removeClass('invalid');
                            }, 500);
                        });
                    }
                    
                    // Clear selection
                    $('.word-search-grid td').removeClass('selected');
                    selectedCells = [];
                };

                // Handle pointer up event
                var onPointerUp = function(e) {
                    if (!isMouseDown) return;
                    e.preventDefault();
                    isMouseDown = false;
                    
                    // Need at least 2 cells to form a word
                    if (selectedCells.length < 2) {
                        $('.word-search-grid td').removeClass('selected');
                        selectedCells = [];
                        return;
                    }
                    
                    // Get the selected word in both directions
                    var selectedWord = '';
                    selectedCells.forEach(function(cell) {
                        selectedWord += cell.text().toLowerCase();
                    });
                    
                    // Check for words in both directions
                    var foundWord = null;
                    var reversedWord = selectedWord.split('').reverse().join('');
                    
                    // Check both the selected word and its reverse
                    self.words.forEach(function(word) {
                        var lowerWord = word.toLowerCase();
                        if (lowerWord === selectedWord || lowerWord === reversedWord) {
                            foundWord = word;
                        }
                    });
                    
                    if (foundWord) {
                        // Mark cells as found
                        selectedCells.forEach(function(cell) {
                            cell.addClass('found');
                        });
                        
                        // Mark word as found in the list
                        $('.word-search-word-list li').each(function() {
                            if ($(this).text().toLowerCase() === foundWord.toLowerCase()) {
                                $(this).addClass('found');
                            }
                        });
                        
                        // Check if all words are found
                        self.checkWin();
                    } else {
                        // Visual feedback for invalid selection
                        selectedCells.forEach(function(cell) {
                            cell.addClass('invalid');
                            setTimeout(function() {
                                cell.removeClass('invalid');
                            }, 500);
                        });
                    }
                    
                    // Clear selection
                    $('.word-search-grid td').removeClass('selected');
                    selectedCells = [];
                };
                
                // Add event listeners to the grid
                var grid = $('.word-search-grid');
                
                // Bind events to the grid
                grid.on({
                    'mousedown touchstart': onPointerDown,
                    'mousemove touchmove': onPointerMove,
                    'mouseup touchend mouseleave': onPointerUp
                });
                
                // Also bind mouseup to document as a fallback
                $(document).on('mouseup touchend', function(e) {
                    if (isMouseDown) {
                        onPointerUp(e);
                    }
                });
            },
            
            /**
             * Check if all words have been found
             */
            checkWin: function() {
                var allFound = true;
                $('.word-search-word-list li').each(function() {
                    if (!$(this).hasClass('found')) {
                        allFound = false;
                        return false; // break the loop
                    }
                });
                
                if (allFound) {
                    setTimeout(function() {
                        alert('Congratulations! You found all the words!');
                    }, 100);
                }
                
                return allFound;
            },
            
            /**
             * Solve the puzzle by revealing all words
             */
            solve: function() {
                var self = this;
                
                // First, clear any existing highlights
                $('.word-search-grid td').removeClass('found');
                
                // Mark all words as found in the list and highlight their cells
                $('.word-search-word-list li').each(function() {
                    var word = $(this).text().toLowerCase();
                    
                    // Mark the word as found in the list
                    $(this).addClass('found');
                    
                    // Find all possible positions of this word in the grid
                    for (var i = 0; i < self.puzzle.grid.length; i++) {
                        for (var j = 0; j < self.puzzle.grid[i].length; j++) {
                            // Check in all 8 possible directions
                            self.checkWordAt(i, j, word);
                        }
                    }
                });
                
                // Disable further interaction
                puzzleContainer.off('mousedown mousemove touchstart touchmove');
                $(document).off('mouseup touchend');
                
                // Show completion message
                setTimeout(function() {
                    alert('Puzzle solved! All words have been highlighted.');
                }, 100);
                
                return true;
            },
            
            /**
             * Check if a word exists at the given position in any direction
             */
            checkWordAt: function(startRow, startCol, word) {
                // Directions: [row, col] for 8 possible directions
                var directions = [
                    [0, 1],   // right
                    [1, 0],   // down
                    [1, 1],   // down-right
                    [1, -1],  // down-left
                    [0, -1],  // left
                    [-1, 0],  // up
                    [-1, -1], // up-left
                    [-1, 1]   // up-right
                ];
                
                // Check each direction
                for (var d = 0; d < directions.length; d++) {
                    var dir = directions[d];
                    var found = true;
                    var cells = [];
                    
                    // Check each character in the word
                    for (var i = 0; i < word.length; i++) {
                        var row = startRow + i * dir[0];
                        var col = startCol + i * dir[1];
                        
                        // Check bounds
                        if (row < 0 || row >= this.puzzle.grid.length || 
                            col < 0 || col >= this.puzzle.grid[0].length) {
                            found = false;
                            break;
                        }
                        
                        // Check if the character matches
                        if (this.puzzle.grid[row][col].toLowerCase() !== word[i]) {
                            found = false;
                            break;
                        }
                        
                        // Store the cell position
                        cells.push({row: row, col: col});
                    }
                    
                    // If word found in this direction, highlight the cells
                    if (found && cells.length === word.length) {
                        cells.forEach(function(cell) {
                            $('.word-search-grid td[data-row="' + cell.row + '"][data-col="' + cell.col + '"]')
                                .addClass('found');
                        });
                        return true;
                    }
                }
                
                return false;
            }
        };
        
        // Initialize the game
        game.init();
        
        // Event handlers
        solveButton.on('click', function() {
            game.solve();
        });
        
        newGameButton.on('click', function() {
            game.generatePuzzle();
            game.renderWords();
        });
    });
});
