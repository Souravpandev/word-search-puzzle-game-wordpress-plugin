<?php
class Word_Search_Public {
    public function __construct() {
        add_action('wp_head', array($this, 'add_web_application_schema'));
    }
    public function enqueue_styles() {
        wp_enqueue_style('word-search-public', plugin_dir_url(dirname(__FILE__)) . 'public/css/word-search-public.css', array(), WORD_SEARCH_VERSION, 'all');
    }

    public function enqueue_scripts() {
        // Only load on single word search pages or posts
        if (!is_singular('wordsearch') && !is_post_type_archive('wordsearch')) {
            return;
        }
        
        // Enqueue Wordfind.js with defer
        wp_enqueue_script(
            'wordfind', 
            plugin_dir_url(dirname(__FILE__)) . 'public/js/wordfind.js', 
            array('jquery'), 
            '1.0', 
            array(
                'in_footer' => true,
                'strategy'  => 'defer',
            )
        );
        
        // Enqueue our public script with wordfind as a dependency
        wp_enqueue_script(
            'word-search-public', 
            plugin_dir_url(dirname(__FILE__)) . 'public/js/word-search-public.js', 
            array('jquery', 'wordfind'), 
            WORD_SEARCH_VERSION, 
            array(
                'in_footer' => true,
                'strategy'  => 'defer',
            )
        );
        
        // Enqueue timer script
        wp_enqueue_script(
            'word-search-timer',
            plugin_dir_url(dirname(__FILE__)) . 'public/js/word-search-timer.js',
            array('jquery'),
            WORD_SEARCH_VERSION,
            array(
                'in_footer' => true,
                'strategy'  => 'defer',
            )
        );
        
        // Enqueue jsPDF library
        wp_enqueue_script(
            'jspdf',
            'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js',
            array(),
            '2.5.1',
            array(
                'in_footer' => true,
                'strategy'  => 'defer',
            )
        );
        
        // Enqueue html2canvas for DOM to image conversion
        wp_enqueue_script(
            'html2canvas',
            'https://html2canvas.hertzen.com/dist/html2canvas.min.js',
            array(),
            '1.4.1',
            array(
                'in_footer' => true,
                'strategy'  => 'defer',
            )
        );
        
        // Enqueue print script
        wp_enqueue_script(
            'word-search-print',
            plugin_dir_url(dirname(__FILE__)) . 'public/js/word-search-print.js',
            array('jquery', 'jspdf', 'html2canvas'),
            WORD_SEARCH_VERSION,
            array(
                'in_footer' => true,
                'strategy'  => 'defer',
            )
        );
        
        // Localize script with AJAX URL and other variables
        wp_localize_script('word-search-public', 'wordSearchVars', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('word_search_nonce')
        ));
    }
    
    public function add_web_application_schema() {
        if (!is_singular('wordsearch')) {
            return;
        }
        
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'WebApplication',
            'name' => get_the_title(),
            'operatingSystem' => 'All',
            'applicationCategory' => 'Educational',
            'applicationSubCategory' => 'Word Puzzle Game',
            'description' => get_the_excerpt() ?: 'Interactive word search puzzle',
            'url' => get_permalink(),
            'inLanguage' => get_bloginfo('language'),
            'offers' => array(
                '@type' => 'Offer',
                'price' => '0',
                'priceCurrency' => 'USD'
            ),
            'publisher' => array(
                '@type' => 'Organization',
                'name' => get_bloginfo('name'),
                'url' => home_url()
            ),
            'isAccessibleForFree' => true,
            'browserRequirements' => 'Requires JavaScript',
            'softwareVersion' => '1.0',
            'keywords' => array('word search', 'puzzle', 'educational')
        );
        
        echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>' . "\n";
    }
}