<?php
class Word_Search {
    public function run() {
        $this->load_dependencies();
        $this->register_post_type();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }

    private function load_dependencies() {
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-word-search-admin.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'public/class-word-search-public.php';
    }

    private function register_post_type() {
        add_action('init', array($this, 'register_word_search_post_type'));
    }

    public function register_word_search_post_type() {
        $labels = array(
            'name'                  => _x('Word Searches', 'Post Type General Name', 'word-search'),
            'singular_name'         => _x('Word Search', 'Post Type Singular Name', 'word-search'),
            'menu_name'             => __('Word Search', 'word-search'),
            'name_admin_bar'        => __('Word Search', 'word-search'),
            'archives'              => __('Word Search Archives', 'word-search'),
            'attributes'            => __('Word Search Attributes', 'word-search'),
            'parent_item_colon'     => __('Parent Word Search:', 'word-search'),
            'all_items'             => __('All Word Searches', 'word-search'),
            'add_new_item'          => __('Add New Word Search', 'word-search'),
            'add_new'               => __('Add New', 'word-search'),
            'new_item'              => __('New Word Search', 'word-search'),
            'edit_item'             => __('Edit Word Search', 'word-search'),
            'update_item'           => __('Update Word Search', 'word-search'),
            'view_item'             => __('View Word Search', 'word-search'),
            'view_items'            => __('View Word Searches', 'word-search'),
            'search_items'          => __('Search Word Search', 'word-search'),
            'not_found'             => __('Not found', 'word-search'),
            'not_found_in_trash'    => __('Not found in Trash', 'word-search'),
            'featured_image'        => __('Featured Image', 'word-search'),
            'set_featured_image'    => __('Set featured image', 'word-search'),
            'remove_featured_image' => __('Remove featured image', 'word-search'),
            'use_featured_image'    => __('Use as featured image', 'word-search'),
            'insert_into_item'      => __('Insert into word search', 'word-search'),
            'uploaded_to_this_item' => __('Uploaded to this word search', 'word-search'),
            'items_list'            => __('Word searches list', 'word-search'),
            'items_list_navigation' => __('Word searches list navigation', 'word-search'),
            'filter_items_list'     => __('Filter word searches list', 'word-search'),
        );

        $args = array(
            'label'                 => __('Word Search', 'word-search'),
            'description'           => __('Create and manage word search puzzles', 'word-search'),
            'labels'                => $labels,
            'supports'              => array('title', 'editor', 'thumbnail', 'comments'),
            'hierarchical'          => false,
            'public'                => true,
            'show_ui'               => true,
            'show_in_menu'          => true,
            'menu_position'         => 5,
            'menu_icon'             => 'dashicons-grid-view',
            'show_in_admin_bar'     => true,
            'show_in_nav_menus'     => true,
            'can_export'            => true,
            'has_archive'           => true,
            'exclude_from_search'   => false,
            'publicly_queryable'    => true,
            'capability_type'       => 'post',
            'show_in_rest'          => true,
            'taxonomies'            => array('wordsearch_category'),
            // Enable comments by default for new posts
            'supports'              => array('title', 'editor', 'thumbnail', 'comments'),
            'comments'              => true,
        );
        
        // Set default comment status to 'open' for new posts
        add_action('wp_insert_post', function($post_id, $post) {
            if ('wordsearch' === $post->post_type && 'auto-draft' === $post->post_status) {
                update_post_meta($post_id, '_wp_page_template', 'default');
                wp_update_post(array(
                    'ID' => $post_id,
                    'comment_status' => 'open',
                    'ping_status'    => 'open',
                ));
            }
        }, 10, 2);
        
        // Register the custom post type
        register_post_type('wordsearch', $args);
        
        // Register custom taxonomy for Word Search categories
        $this->register_word_search_taxonomy();

        // Post type registration is now handled in the $args array above
    }

    /**
     * Register custom taxonomy for Word Search categories
     */
    private function register_word_search_taxonomy() {
        $labels = array(
            'name'              => _x('Word Search Categories', 'taxonomy general name', 'word-search'),
            'singular_name'     => _x('Word Search Category', 'taxonomy singular name', 'word-search'),
            'search_items'      => __('Search Categories', 'word-search'),
            'all_items'         => __('All Categories', 'word-search'),
            'parent_item'       => __('Parent Category', 'word-search'),
            'parent_item_colon' => __('Parent Category:', 'word-search'),
            'edit_item'         => __('Edit Category', 'word-search'),
            'update_item'       => __('Update Category', 'word-search'),
            'add_new_item'      => __('Add New Category', 'word-search'),
            'new_item_name'     => __('New Category Name', 'word-search'),
            'menu_name'         => __('Categories', 'word-search'),
        );

        $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array('slug' => 'wordsearch-category'),
            'show_in_rest'      => true,
        );

        register_taxonomy('wordsearch_category', array('wordsearch'), $args);
    }

    private function define_admin_hooks() {
        $plugin_admin = new Word_Search_Admin();
        add_action('admin_enqueue_scripts', array($plugin_admin, 'enqueue_styles'));
        add_action('admin_enqueue_scripts', array($plugin_admin, 'enqueue_scripts'));
        
        // Add meta boxes
        add_action('add_meta_boxes', array($this, 'add_word_search_meta_boxes'));
        add_action('save_post_wordsearch', array($this, 'save_word_search_meta'));
        
        // Force enable comments for all Word Search posts
        add_action('wp_insert_post', array($this, 'force_enable_comments'), 10, 3);
    }
    
    /**
     * Force enable comments for all Word Search posts
     */
    public function force_enable_comments($post_id, $post, $update) {
        // Only target our custom post type
        if ('wordsearch' !== $post->post_type) {
            return;
        }
        
        // Don't update if this is just a revision or auto-save
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return;
        }
        
        // Unhook this function to prevent infinite loops
        remove_action('save_post_wordsearch', array($this, 'save_word_search_meta'));
        
        // Update the post to enable comments
        wp_update_post(array(
            'ID' => $post_id,
            'comment_status' => 'open'
        ));
        
        // Re-hook this function
        add_action('save_post_wordsearch', array($this, 'save_word_search_meta'));
    }

    public function add_word_search_meta_boxes() {
        add_meta_box(
            'word_search_words',
            __('Word Search Words', 'word-search'),
            array($this, 'word_search_words_meta_box'),
            'wordsearch',
            'normal',
            'high'
        );
    }

    public function word_search_words_meta_box($post) {
        // Add nonce for security and authentication
        wp_nonce_field('word_search_meta_box', 'word_search_meta_box_nonce');
        
        // Get saved words if they exist
        $words = get_post_meta($post->ID, '_word_search_words', true);
        $words = $words ? implode("\n", $words) : '';
        ?>
        <div class="word-search-meta-box">
            <p>
                <label for="word_search_words"><?php _e('Enter words (one per line):', 'word-search'); ?></label><br>
                <textarea name="word_search_words" id="word_search_words" rows="10" style="width: 100%;"><?php echo esc_textarea($words); ?></textarea>
            </p>
            <p class="description">
                <?php _e('Enter the words you want to include in the word search puzzle, one word per line.', 'word-search'); ?>
            </p>
        </div>
        <?php
    }

    public function save_word_search_meta($post_id) {
        // Check if nonce is set
        if (!isset($_POST['word_search_meta_box_nonce'])) {
            return $post_id;
        }

        // Verify nonce
        if (!wp_verify_nonce($_POST['word_search_meta_box_nonce'], 'word_search_meta_box')) {
            return $post_id;
        }

        // Check if autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return $post_id;
        }

        // Check user permissions
        if ('wordsearch' === $_POST['post_type']) {
            if (!current_user_can('edit_post', $post_id)) {
                return $post_id;
            }
        }

        // Save words
        if (isset($_POST['word_search_words'])) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'wordsearch';
            
            // Process words
            $words = explode("\n", sanitize_textarea_field($_POST['word_search_words']));
            $words = array_map('trim', $words);
            $words = array_filter($words); // Remove empty lines
            
            // Save to post meta for backward compatibility
            update_post_meta($post_id, '_word_search_words', $words);
            
            // Generate puzzle data
            $puzzle_data = $this->generate_puzzle_data($words);
            
            // Prepare data for database
            $data = array(
                'title' => get_the_title($post_id),
                'words' => maybe_serialize($words),
                'grid' => maybe_serialize($puzzle_data['grid']),
                'settings' => maybe_serialize(array(
                    'width' => 12,
                    'height' => 12,
                    'fill_blanks' => true,
                    'max_attempts' => 20,
                    'max_grid_growth' => 10
                ))
            );
            
            // Check if record exists
            $existing = $wpdb->get_row($wpdb->prepare(
                "SELECT id FROM $table_name WHERE id = %d",
                $post_id
            ));
            
            if ($existing) {
                // Update existing record
                $wpdb->update(
                    $table_name,
                    $data,
                    array('id' => $post_id),
                    array('%s', '%s', '%s', '%s'),
                    array('%d')
                );
            } else {
                // Insert new record
                $data['id'] = $post_id;
                $wpdb->insert(
                    $table_name,
                    $data,
                    array('%d', '%s', '%s', '%s', '%s')
                );
            }
        }
    }

    private function define_public_hooks() {
        $plugin_public = new Word_Search_Public();
        add_action('wp_enqueue_scripts', array($plugin_public, 'enqueue_styles'));
        add_action('wp_enqueue_scripts', array($plugin_public, 'enqueue_scripts'));
        
        // Add shortcode
        add_shortcode('wordsearch', array($this, 'word_search_shortcode'));
        
        // Add template loading
        add_filter('template_include', array($this, 'load_word_search_template'));
        
        // Add body class for word search single pages
        add_filter('body_class', array($this, 'add_word_search_body_class'));
    }
    
    /**
     * Load custom templates for Word Search
     */
    public function load_word_search_template($template) {
        // Handle single word search posts
        if (is_singular('wordsearch')) {
            // First check if the theme has a custom template
            $theme_template = locate_template(array('single-wordsearch.php'));
            
            if ($theme_template) {
                return $theme_template;
            }
            
            // Otherwise, use the plugin's template
            $plugin_template = plugin_dir_path(dirname(__FILE__)) . 'templates/single-wordsearch.php';
            
            if (file_exists($plugin_template)) {
                return $plugin_template;
            }
        }
        
        // Handle word search category archives
        if (is_tax('wordsearch_category')) {
            // First check if the theme has a custom template
            $theme_templates = array(
                'taxonomy-wordsearch-category.php',
                'taxonomy-wordsearch_category.php',
                'archive-wordsearch.php'
            );
            
            $theme_template = locate_template($theme_templates);
            
            if ($theme_template) {
                return $theme_template;
            }
            
            // Otherwise, use the plugin's template from the templates directory
            $plugin_template = plugin_dir_path(dirname(__FILE__)) . 'templates/taxonomy-wordsearch-category.php';
            
            if (file_exists($plugin_template)) {
                return $plugin_template;
            }
        }
        
        return $template;
    }
    
    /**
     * Add custom body class for Word Search single pages
     */
    public function add_word_search_body_class($classes) {
        if (is_singular('wordsearch')) {
            $classes[] = 'word-search-single-page';
        }
        return $classes;
    }

    /**
     * Generate puzzle data using Wordfind.js
     */
    private function generate_puzzle_data($words) {
        if (empty($words)) {
            return array(
                'grid' => array(),
                'words' => array()
            );
        }
        
        // Include Wordfind.js classes if not already included
        if (!class_exists('WordFind\WordFind')) {
            require_once WORD_SEARCH_PLUGIN_DIR . 'includes/wordfind/WordFind.php';
            require_once WORD_SEARCH_PLUGIN_DIR . 'includes/wordfind/WordFindGrid.php';
        }
        
        try {
            $settings = array(
                'width' => 12,
                'height' => 12,
                'fillBlanks' => true,
                'maxAttempts' => 20,
                'maxGridGrowth' => 10
            );
            
            $wordFind = new WordFind\WordFind($words, $settings);
            $grid = $wordFind->getGrid();
            $placed_words = $wordFind->getPlacedWords();
            
            return array(
                'grid' => $grid,
                'words' => $placed_words
            );
            
        } catch (Exception $e) {
            error_log('Error generating word search puzzle: ' . $e->getMessage());
            return array(
                'grid' => array(),
                'words' => array()
            );
        }
    }
    
    /**
     * Get word search data from custom table
     */
    private function get_word_search_data($post_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wordsearch';
        
        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE id = %d",
            $post_id
        ));
        
        if ($result) {
            return array(
                'id' => $result->id,
                'title' => $result->title,
                'words' => maybe_unserialize($result->words),
                'grid' => maybe_unserialize($result->grid),
                'settings' => maybe_unserialize($result->settings),
                'created_at' => $result->created_at,
                'updated_at' => $result->updated_at
            );
        }
        
        // Fallback to post meta if no custom table entry exists
        $words = get_post_meta($post_id, '_word_search_words', true);
        if (!empty($words)) {
            $puzzle_data = $this->generate_puzzle_data($words);
            return array(
                'id' => $post_id,
                'title' => get_the_title($post_id),
                'words' => $words,
                'grid' => $puzzle_data['grid'],
                'settings' => array(
                    'width' => 12,
                    'height' => 12,
                    'fill_blanks' => true,
                    'max_attempts' => 20,
                    'max_grid_growth' => 10
                ),
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            );
        }
        
        return false;
    }
    
    public function word_search_shortcode($atts) {
        $atts = shortcode_atts(array(
            'id' => 0,
        ), $atts, 'wordsearch');

        $post_id = intval($atts['id']);
        if (!$post_id) {
            return '<p>Error: No word search ID provided.</p>';
        }
        
        // Get word search data
        $word_search = $this->get_word_search_data($post_id);
        
        if (!$word_search || empty($word_search['words'])) {
            return '<p>No word search data found.</p>';
        }
        
        // Enqueue necessary scripts and styles
        wp_enqueue_style('word-search-public');
        wp_enqueue_script('wordfind');
        wp_enqueue_script('wordfind-js');
        wp_enqueue_script('word-search-public');
        
        // Prepare data for JavaScript
        $js_data = array(
            'grid' => $word_search['grid'],
            'words' => $word_search['words'],
            'settings' => $word_search['settings']
        );
        
        // Localize script with puzzle data
        wp_localize_script('word-search-public', 'wordSearchData', array(
            'puzzle' => $js_data
        ));
        
        ob_start();
        ?>
        <div class="word-search-container" 
             id="word-search-<?php echo esc_attr($post_id); ?>"
             data-words='<?php echo esc_attr(json_encode($word_search['words'])); ?>'
             data-settings='<?php echo esc_attr(json_encode($word_search['settings'])); ?>'>
            
            <h2 class="word-search-title"><?php echo esc_html($word_search['title']); ?></h2>
            
            <div class="word-search-puzzle">
                <div id="puzzle-<?php echo esc_attr($post_id); ?>" class="puzzle">
                    <?php 
                    // Output the puzzle grid as fallback (will be replaced by JS)
                    if (!empty($word_search['grid'])) {
                        echo '<div class="puzzle-grid">';
                        foreach ($word_search['grid'] as $row) {
                            echo '<div class="puzzle-row">';
                            foreach ($row as $cell) {
                                echo '<div class="puzzle-cell">' . esc_html($cell) . '</div>';
                            }
                            echo '</div>';
                        }
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>
            
            <div class="word-search-words">
                <h3><?php _e('Words to Find:', 'word-search'); ?></h3>
                <ul class="word-search-word-list">
                    <?php foreach ($word_search['words'] as $word) : ?>
                        <li data-word="<?php echo esc_attr(strtolower($word)); ?>">
                            <?php echo esc_html($word); ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            
            <div class="word-search-controls">
                <button class="button solve-puzzle"><?php _e('Solve Puzzle', 'word-search'); ?></button>
                <button class="button new-puzzle" style="margin-left: 10px;"><?php _e('New Puzzle', 'word-search'); ?></button>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}