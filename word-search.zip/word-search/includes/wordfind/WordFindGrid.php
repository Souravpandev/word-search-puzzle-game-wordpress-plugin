<?php
namespace WordFind;

/**
 * Class WordFindGrid
 * 
 * Handles the grid operations for the word search puzzle
 */
class WordFindGrid {
    private $width;
    private $height;
    private $grid = array();
    private $placedWords = array();
    private $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    
    /**
     * Constructor
     * 
     * @param int $width  Grid width
     * @param int $height Grid height
     */
    public function __construct($width, $height) {
        $this->width = $width;
        $this->height = $height;
        $this->initializeGrid();
    }
    
    /**
     * Initialize the grid with empty cells
     */
    private function initializeGrid() {
        $this->grid = array_fill(0, $this->height, array_fill(0, $this->width, ''));
    }
    
    /**
     * Try to place a word in the grid
     * 
     * @param string $word      The word to place
     * @param array  $direction Direction to place the word (dx, dy)
     * @param int    $x         Starting x-coordinate
     * @param int    $y         Starting y-coordinate
     * @return bool True if the word was placed successfully
     */
    public function placeWord($word, $direction, $x, $y) {
        $word = strtoupper(trim($word));
        $length = strlen($word);
        
        // Check if the word fits in the grid
        $endX = $x + ($direction[0] * ($length - 1));
        $endY = $y + ($direction[1] * ($length - 1));
        
        if ($endX < 0 || $endX >= $this->width || $endY < 0 || $endY >= $this->height) {
            return false;
        }
        
        // Check if the word can be placed without conflicts
        for ($i = 0; $i < $length; $i++) {
            $checkX = $x + ($direction[0] * $i);
            $checkY = $y + ($direction[1] * $i);
            
            $cell = $this->grid[$checkY][$checkX];
            
            // If the cell is not empty and doesn't match the current letter, can't place here
            if ($cell !== '' && $cell !== $word[$i]) {
                return false;
            }
        }
        
        // Place the word in the grid
        for ($i = 0; $i < $length; $i++) {
            $placeX = $x + ($direction[0] * $i);
            $placeY = $y + ($direction[1] * $i);
            
            $this->grid[$placeY][$placeX] = $word[$i];
        }
        
        // Record the placed word
        $this->placedWords[] = array(
            'word' => $word,
            'start' => array($x, $y),
            'end' => array($endX, $endY),
            'direction' => $direction
        );
        
        return true;
    }
    
    /**
     * Fill empty cells with random letters
     */
    public function fillEmptyCells() {
        for ($y = 0; $y < $this->height; $y++) {
            for ($x = 0; $x < $this->width; $x++) {
                if ($this->grid[$y][$x] === '') {
                    $this->grid[$y][$x] = $this->getRandomLetter();
                }
            }
        }
    }
    
    /**
     * Get a random letter from the alphabet
     * 
     * @return string A random uppercase letter
     */
    private function getRandomLetter() {
        return $this->alphabet[rand(0, strlen($this->alphabet) - 1)];
    }
    
    /**
     * Get the grid
     * 
     * @return array The grid
     */
    public function getGrid() {
        return $this->grid;
    }
    
    /**
     * Get the list of placed words
     * 
     * @return array List of placed words with their positions
     */
    public function getPlacedWords() {
        // Return just the words for simplicity
        return array_map(function($item) {
            return $item['word'];
        }, $this->placedWords);
    }
    
    /**
     * Get the grid as a string
     * 
     * @return string The grid as a string
     */
    public function __toString() {
        $output = '';
        foreach ($this->grid as $row) {
            $output .= implode(' ', $row) . "\n";
        }
        return $output;
    }
}
