<?php
namespace WordFind;

/**
 * Class WordFind
 * 
 * Main class for generating word search puzzles
 */
class WordFind {
    private $words = array();
    private $settings = array(
        'width' => 12,
        'height' => 12,
        'fillBlanks' => true,
        'maxAttempts' => 20,
        'maxGridGrowth' => 10
    );
    
    private $grid;
    private $directions = array(
        array(1, 0),   // Right
        array(1, 1),   // Down-right
        array(0, 1),   // Down
        array(-1, 1),  // Down-left
        array(-1, 0),  // Left
        array(-1, -1), // Up-left
        array(0, -1),  // Up
        array(1, -1)   // Up-right
    );
    
    /**
     * Constructor
     * 
     * @param array $words    Array of words to include in the puzzle
     * @param array $settings Optional settings to override defaults
     */
    public function __construct($words, $settings = array()) {
        $this->words = array_map('strtoupper', $words);
        $this->settings = array_merge($this->settings, $settings);
        
        // Sort words by length (longest first) to place them first
        usort($this->words, function($a, $b) {
            return strlen($b) - strlen($a);
        });
        
        $this->initializeGrid();
    }
    
    /**
     * Initialize the grid with the specified dimensions
     */
    private function initializeGrid() {
        $this->grid = new WordFindGrid(
            $this->settings['width'],
            $this->settings['height']
        );
    }
    
    /**
     * Generate the word search puzzle
     * 
     * @return array The generated puzzle grid
     */
    public function generate() {
        $attempts = 0;
        $placedWords = array();
        $unplacedWords = array();
        
        // Try to place each word
        foreach ($this->words as $word) {
            $word = strtoupper(trim($word));
            if (empty($word)) continue;
            
            $placed = $this->placeWord($word);
            
            if ($placed) {
                $placedWords[] = $word;
            } else {
                $unplacedWords[] = $word;
            }
            
            // If we couldn't place a word, try expanding the grid
            if (!empty($unplacedWords) && $attempts < $this->settings['maxAttempts']) {
                $this->expandGrid();
                $attempts++;
                
                // Reset and try again with the expanded grid
                if ($attempts < $this->settings['maxGridGrowth']) {
                    $this->initializeGrid();
                    return $this->generate();
                }
            }
        }
        
        // Fill empty cells with random letters if enabled
        if ($this->settings['fillBlanks']) {
            $this->grid->fillEmptyCells();
        }
        
        return $this->getGrid();
    }
    
    /**
     * Attempt to place a word in the grid
     * 
     * @param string $word The word to place
     * @return bool True if the word was placed successfully
     */
    private function placeWord($word) {
        $length = strlen($word);
        
        // Get all possible starting positions and directions
        $startX = rand(0, $this->settings['width'] - 1);
        $startY = rand(0, $this->settings['height'] - 1);
        
        // Try all directions from the starting position
        $directions = $this->directions;
        shuffle($directions);
        
        foreach ($directions as $direction) {
            // Check if the word fits in this direction
            $endX = $startX + ($direction[0] * ($length - 1));
            $endY = $startY + ($direction[1] * ($length - 1));
            
            if ($endX >= 0 && $endX < $this->settings['width'] &&
                $endY >= 0 && $endY < $this->settings['height']) {
                
                // Try to place the word
                if ($this->grid->placeWord($word, $direction, $startX, $startY)) {
                    return true;
                }
            }
        }
        
        // If we couldn't place the word from the random start position,
        // try all possible positions (slower but more thorough)
        for ($y = 0; $y < $this->settings['height']; $y++) {
            for ($x = 0; $x < $this->settings['width']; $x++) {
                shuffle($directions);
                
                foreach ($directions as $direction) {
                    $endX = $x + ($direction[0] * ($length - 1));
                    $endY = $y + ($direction[1] * ($length - 1));
                    
                    if ($endX >= 0 && $endX < $this->settings['width'] &&
                        $endY >= 0 && $endY < $this->settings['height']) {
                        
                        if ($this->grid->placeWord($word, $direction, $x, $y)) {
                            return true;
                        }
                    }
                }
            }
        }
        
        return false;
    }
    
    /**
     * Expand the grid dimensions to fit more words
     */
    private function expandGrid() {
        $this->settings['width'] = min(
            $this->settings['width'] + 2,
            $this->settings['width'] + $this->settings['maxGridGrowth']
        );
        
        $this->settings['height'] = min(
            $this->settings['height'] + 2,
            $this->settings['height'] + $this->settings['maxGridGrowth']
        );
        
        $this->initializeGrid();
    }
    
    /**
     * Get the generated grid
     * 
     * @return array The puzzle grid
     */
    public function getGrid() {
        return $this->grid->getGrid();
    }
    
    /**
     * Get the list of placed words
     * 
     * @return array List of placed words
     */
    public function getPlacedWords() {
        return $this->grid->getPlacedWords();
    }
    
    /**
     * Get the current grid dimensions
     * 
     * @return array Array with 'width' and 'height' keys
     */
    public function getDimensions() {
        return array(
            'width' => $this->settings['width'],
            'height' => $this->settings['height']
        );
    }
}
