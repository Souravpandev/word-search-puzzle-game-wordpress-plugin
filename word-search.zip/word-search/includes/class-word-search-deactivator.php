<?php
class Word_Search_Deactivator {
    public static function deactivate() {
        // Deactivation code if needed
    }
}